package main;

import java.util.Arrays;

public class Main {

	public static void main(String[] args) {
		System.out.println("Printing something using a void-function:");
		makeVoid(10);
		System.out.println("Printing the same using a non-void-function:");
		System.out.println(makeString());
		
		System.out.println("Different handling but same results. \n");
		
		System.out.println("In the makeVoid() we used a parameter n to differ the range: ");
		System.out.print("n = 1: ");
		makeVoid(1);
		System.out.println();
		System.out.print("n = 20: ");
		makeVoid(20);
		
		System.out.println();
		System.out.println();
		System.out.println("Lastly, iterating trough an 1D-array and filling it:");
		fillArray();
	}

	/**
	 * Printing all numbers between 0 and n (excl.) separated by a blank directly
	 * (This doesn't need a System.out.println(); but uses a parameter n to determine the range)
	 */

	private static void makeVoid(double n) {
		for (int i = 0; i < n; i++) {
			System.out.print(i + " ");
		}
	}

	/**
	 * Creating a string of all numbers between 0 and 9 (incl.) separated by a blank
	 * (This one returns only a String and needs to be printed using
	 * System.out.println();)
	 */

	private static String makeString() {
		String res = "";

		for (int i = 0; i < 10; i++) {
			res += i + " ";
		}

		return res;
	}

	/**
	 * An example how to fill an array and printing it.
	 * 
	 * !!! If you have to print an Array you're usually not allowed to use
	 * Arrays.toString() !!!
	 * 
	 */

	private static void fillArray() {
		int[] schrank = new int[20];
		for (int i = 0; i < schrank.length; i++) {
			schrank[i] = i;
		}
		// Don't print an array like his in an exercise
		System.out.println(Arrays.toString(schrank));
	}
}

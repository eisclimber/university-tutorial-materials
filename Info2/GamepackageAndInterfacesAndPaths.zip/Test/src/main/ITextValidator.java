package main;

public interface ITextValidator {
	
	public boolean validateFile(String filePath);
	
}

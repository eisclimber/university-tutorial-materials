package main;

public class RickrollException extends Exception {

	private static final long serialVersionUID = -6192085729515853460L;

	// Parameterless Constructor
	public RickrollException() { }

	// Constructor that accepts a message
	public RickrollException(String message) {
		super("You go rick rolled: " + message);
	}

}

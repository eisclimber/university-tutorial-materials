package main;

import java.io.IOException;

public interface IReader {
	
	public String readFileAt(String filePath) throws IOException, RickrollException;
}

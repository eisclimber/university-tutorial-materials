package main;

public interface ISmartScience {
	
	public void doScience();
	
}

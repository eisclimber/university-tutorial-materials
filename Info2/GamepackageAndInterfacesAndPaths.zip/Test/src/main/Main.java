package main;

import java.io.File;
import java.io.IOException;

public class Main {

	public static void main(String[] args)
	{
		MortyReader morty = new MortyReader();
		
		RickReader rick = new RickReader(morty);
		
		rick.doScience();
		
		System.out.println();
		
		// Relative Path
		morty.validateFile("./resources/TestText1.txt"); 
		
		System.out.println("-----------------------------------------------------");
		// Relative path (automatically imply root './')
		rick.validateFile("resources/TestText1.txt");
		System.out.println("-----------------------------------------------------");
		// Relative Path using '..' going back to previous
		rick.validateFile("./resources/../resources/TestText2.txt"); 
		System.out.println("-----------------------------------------------------");
		// Relative path use Windows backslash (must be escaped -> '\\')
		rick.validateFile(".\\resources\\TestText3.txt");
		System.out.println("-----------------------------------------------------");
		// Absolute path starting from your hard drive
		// Everything else applies, slashes can be exchanged with double backslashes
		rick.validateFile("C:/Users/Luca/eclipse-workspace/Test/resources/TestText3.txt");
	}
}

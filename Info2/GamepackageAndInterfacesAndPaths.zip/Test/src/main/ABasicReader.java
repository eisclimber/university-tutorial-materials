package main;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;

public abstract class ABasicReader implements IReader, ITextValidator {

	public String readFileAt(String filePath) throws IOException, RickrollException {

		InputStream inputStream = null;

		String res = "";
		try {
			BufferedReader buffReader = new BufferedReader(new FileReader(filePath));

			String nextLine;
			char nextChar;

			// Zeilenweise lesen
			while (buffReader.ready()) {
                res += buffReader.readLine() + "\n";
            }

			// Characterweise lesen
//			while (buffReader.ready()) {
//				res += buffReader.read();
//			}
			
			// Hier können wir die RickrollException nicht werfen -> wird vom try-catch abgefangen
//			if (res.contains("Never gonna give you up")) {
//				throw new RickrollException();
//			}
			
			
		} catch (Exception e) {
			// Wir müssen nicht immer 'e.printStackTrace();' schreiben, sondern können auch eigenen Text produzieren
			// String.format() ist ein schönes Konstrukt für Expert*innen unnd Neugierige:D
			System.err.println(String.format("Kein Plan wo da File bei '%s' jetzt schon wieder hin ist...", filePath));
			e.printStackTrace();
		} finally {
			// Wie beim Scanner: Streams immer schließen!
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		if (res.contains("Never gonna give you up")) {
			throw new RickrollException();
		}
		
		return res;

	}

}

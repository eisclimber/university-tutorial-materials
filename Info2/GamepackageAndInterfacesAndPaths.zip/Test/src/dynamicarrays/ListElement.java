package dynamicarrays;

public class ListElement {
		
	// The value stored in the element
	public int value;
	
	// Reference to the next element in the list
	private ListElement next;
	
	
	// Constructor
	public ListElement(int value)
	{
		this.value = value;
	}
	
	
	// Add an entry
	public void appendElement(int elementToAdd)
	{
		if (hasNext()) {
			next.appendElement(elementToAdd);
		}
		/// We are at the end of the list, add a new element
		else {
			next = new ListElement(elementToAdd);
		}
	}
	
	
	// Remove last element
	public void popLastElement() {
		// If the next Element exist but it is the last, remove it
		if (hasNext() && !next.hasNext()) {
			next = null;
		}
		else {
			next.popLastElement();
		}
	}
	
	
	// Return the element at idx (or -1 if not exists)
	public int getElementAt(int idx) {
		// Return this element
		if (idx == 0) {
			return value;
		}
		// Only allow positive indices
		else if (hasNext() && idx > 0) {
			return next.getElementAt(idx - 1);
		}
		// Invalid index, returning -1 as default
		return -1;
	}
	
	
	// Return the length of the list
	public int getListLength() {
		// If we are at the end we have still have this element so the length is 1
		if (!hasNext())
		{
			return 1;
		}
		return next.getListLength() + 1;
	}
	
	
	// Override the toString method for pretty output
	@Override	
	public String toString() {
		if (hasNext()) {
			return (value + ", " + next.toString());
		}
		return (value + "]");
	}

	
	// Element has a next element (is not the last) if next != null
	public boolean hasNext()
	{
		return next != null;
	}
}

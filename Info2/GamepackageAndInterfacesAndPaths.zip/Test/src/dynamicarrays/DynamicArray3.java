package dynamicarrays;

import java.util.Arrays;

public class DynamicArray3 {

	// The array used for storage
	/*
	 *  Note this is private now!!!!!
	 */
	private static int[] array = new int[0];
	
	// Same as before but increase by two
	public static int nextFreeIdx = 0;
	
	
	public static void main(String[] args) {
		System.out.println("Adding 5 Elements to an empty array...");
		System.out.println("-- Accessing an element of an empty array (zero elements): " + getElementAt(0));
		appendElement(1);
		System.out.println("-- Accessing an element inside the range the array: " + getElementAt(0));
		System.out.println("-- Accessing an element NOT inside the range the array: " + getElementAt(1));
		appendElement(3);
		System.out.println("The array after adding 2 elements: " + Arrays.toString(array));
		appendElement(5);
		appendElement(2);
		appendElement(7);
		System.out.println("The array after adding 5 elements: " + Arrays.toString(array));
		System.out.println("--------------------------------");
		System.out.println("Removing 6 Elements from an array with 5 elements...");
		popLastElement();
		popLastElement();
		popLastElement();
		popLastElement();
		System.out.println("The array after removing 4 elements: " + Arrays.toString(array));
		System.out.println("-- Accessing an element inside the range the array: " + getElementAt(0));
		System.out.println("-- Accessing an element NOT inside the range the array: " + getElementAt(1));
		popLastElement();
		popLastElement();
		System.out.println("The array after removing more than the 1 remaining elements: " + Arrays.toString(array));
	}
	
	
	public static void appendElement(int elementToAdd)
	{
		if (array.length <= 0)
		{
			// Create new array with 1 element since we cannot double the size of an empty array
			array = new int[] { elementToAdd };
			nextFreeIdx++;
		}
		else {
			// Resize Array
			int[] newArray = new int[array.length * 2];
			// Copy old values
			if (newArray.length > 1)
			{
				System.arraycopy(array, 0, newArray, 0, array.length);
			}
			// Replace old Array
			array = newArray;
			// Add element
			array[nextFreeIdx] = elementToAdd;
			nextFreeIdx++;
		}
	}
	
	public static void popLastElement() {
		if (nextFreeIdx > 0 && array.length > 0) {
			// Decrease nextFreeIdx
			nextFreeIdx--;

			// We do NOT remove the last element, but simply restrict users from accessing elements outside of our array
			// Since we are in the same class 'System.out.println(Arrays.toString(array));' still works though
		}
	}
	
	public static int getElementAt(int idx) {
		if (idx >= 0 && idx < nextFreeIdx && idx < array.length)
		{
			return array[idx];
		}
		// Invalid index, returning -1 as default
		return -1;
	}
}

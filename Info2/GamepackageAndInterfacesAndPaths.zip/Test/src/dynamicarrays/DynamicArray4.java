package dynamicarrays;

import java.util.Arrays;

public class DynamicArray4 {
	
	// Anchor (= first element) of the list
	private static ListElement anchorElement;
	
	public static void main(String[] args) {
		System.out.println("Adding 5 Elements to an empty array...");
		System.out.println("-- Accessing an element of an empty array (zero elements): " + getElementAt(0));
		appendElement(1);
		System.out.println("-- Accessing an element inside the range the array: " + getElementAt(0));
		System.out.println("-- Accessing an element NOT inside the range the array: " + getElementAt(1));
		appendElement(3);
		System.out.println("The array after adding 2 elements: " + ListToString());
		appendElement(5);
		appendElement(2);
		appendElement(7);
		System.out.println("The array after adding 5 elements: " + ListToString());
		System.out.println("--------------------------------");
		System.out.println("Removing 6 Elements from an array with 5 elements...");
		popLastElement();
		popLastElement();
		popLastElement();
		popLastElement();
		System.out.println("The array after removing 4 elements: " + ListToString());
		System.out.println("-- Accessing an element inside the range the array: " + getElementAt(0));
		System.out.println("-- Accessing an element NOT inside the range the array: " + getElementAt(1));
		popLastElement();
		popLastElement();
		System.out.println("The array after removing more than the 1 remaining elements: " + ListToString());
	}
	
	
	public static void appendElement(int elementToAdd) {
		// We need to handle an empty list here, the rest is done recursively in the ListElements themselves
		if (anchorElement == null) {
			anchorElement = new ListElement(elementToAdd);
		}
		else {
			anchorElement.appendElement(elementToAdd);
		}
	}
	
	
	public static void popLastElement() {
		// If we have at least one element
		if (anchorElement != null) {
			// Remove anchor if it is the last
			if (!anchorElement.hasNext()) {
				anchorElement = null;
			}
			else {
				anchorElement.popLastElement();
			}
		}
	}
	
	
	public static int getElementAt(int idx) {
		// We do NOT need to decrease idx here, as 'this' is not an ListElement
		if (anchorElement != null) {
			return anchorElement.getElementAt(idx);
		}
		// Invalid index, returning -1 as default
		return -1;
	}
	
	
	public static int getListLength()
	{
		if (anchorElement == null) {
			return 0;
		}
		return anchorElement.getListLength();
	}
	
	public static String ListToString() {
		if (anchorElement == null) {
			return "[]";
		}
		return "[" + anchorElement.toString();
	}
}

package gamepackage;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Gallery implements GridGameInterface, MouseListener {

	/**
	 * This "game" created to show how to load images in Eclipse
	 * 
	 * @author This class was created by Luca Dreiling
	 */
	
    private final JPanel myPanel;
    private Rectangle gameArea;
    
    // tileSize fuer die Funktion iniFullGamePanel
    public static final int INIT_TILE_SIZE = 20;
    
    // Datentyp fuer ein Bild
    private BufferedImage image1;
    private BufferedImage image2;
    
    // Speicherort des Bildes (in den Programmdateien)
    // Relativer Speicherpfad (geht vom Programmverzeichnis aus, nicht alle Informationen angegeben)
    private String location1 = "src/image.png";
    private String location2 = "src/eclipse.jpg";
    
    // [Nicht so gut! (Datei befindet sich nicht in den Programmdateien)
    // Absoluter Speicherpfad (alle Informationen sind angegeben)
    // "C:/Users/me/Desktop/eclipse.jpg"
    // "/Users/me/Desktop/eclipse.jpg"]
    
    // Boolean zur Unterscheidung der beiden Bilder
    boolean firstImage = true;
    
	public Gallery(JFrame myFrame, JPanel yourPanel, Rectangle gameArea, Rectangle controlArea) {
		this.gameArea = new Rectangle(gameArea);
        this.myPanel = yourPanel;
        this.myPanel.addMouseListener(this);
        
        init();

        myFrame.setFocusable(true);
	}
    
	/**
	 * 	That loads the image.
	 *  The whole thing needs to be surrounded, by a try-catch.
	 *  Eclipse tries to load everything in the try-block 
	 *  but if it doesn't succeed it handles the exception in the catch-block
	 */
	
    private void init() {
    	try {												// Versuche das Bild zu laden
    		image1 = ImageIO.read(new File(location1)); 	// Lade das Bild ins Programm
    		image2 = ImageIO.read(new File(location2)); 	// Lade das andere Bild ins Programm
    	} catch (Exception e) {								// Wenn etwas nicht funktioniert (z.B. Bild nicht gefunden)
    		e.printStackTrace();							// Ausgabe des Fehlers
    		System.exit(-1);								// Beende das Programm
    	}
    }
    

	@Override
	public void paintGameArea(Graphics2D g) {
		// Hintergrund der GameArea
		g.setColor(Color.PINK);
		g.fill(gameArea);
		
		// Darstellen des Bildes
		if (firstImage) {
			g.drawImage(image1, (int) gameArea.getX(), (int) gameArea.getY(),
					(int) gameArea.getWidth(), (int) gameArea.getHeight(), null);
		} else {
			g.drawImage(image2, (int) gameArea.getX(), (int) gameArea.getY(),
					(int) gameArea.getWidth(), (int) gameArea.getHeight(), null);
		}
	}

    
	
	@Override
	public GameScores getScores() {
		return GameScores.createGameScores("The Answer", 42);
	}

	@Override
	public void closeGame() {
        this.myPanel.removeMouseListener(this);
    }

	@Override
	public void paintControlArea(Graphics2D g) { }

	@Override
	public String getName() {
		return "Gallery";
	}

	//////////////////////////////////////////////////////////////////////////////////////////////
	
	
	/*
	 * Mouse Listener
	 */
	
	/**
	 * Mouse Click changes the displayed image
	 */
	
	@Override
	public void mouseClicked(MouseEvent e) {
		firstImage = !firstImage;
		myPanel.repaint();
	}

	// unused 
	
	@Override
	public void mouseEntered(MouseEvent e) { }

	@Override
	public void mouseExited(MouseEvent e) { }

	@Override
	public void mousePressed(MouseEvent e) { }

	@Override
	public void mouseReleased(MouseEvent arg0) { }

}
//@author Luca Dreiling
package gamepackage;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;


public class Paint implements GridGameInterface, MouseListener, ActionListener {

	/**
	 * This is a very basic version of Paint.
	 * 
	 * @author This class was created by Luca Dreiling
	 */
	
	// The game area in Rectangle format.
	private Rectangle gameArea;

	// The control area - where the speed should be shown.
	private Rectangle controlArea;

	// area within the game area where you paint
	private Rectangle paintArea;

	// The panel in which all this happens.
	private JPanel myPanel;

	// initial width=height of a tile
	public static int initTileSize = 20;

	// the actual current width=height of a tile
	private int tileSize;

	// Number of Grid rows of the grid game area.
	public int numRows;

	// Number of grid columns of the grid game area.
	public int numColumns;

	// Reference to the frame in which the game is played.
	private JFrame inFrame;	
	
	/*-----------------------------------------------------------
	*		 Here are the additional variables we need
	*------------------------------------------------------------*/

	// How many Objects can be drawn simultaneously
	private static final int MAX_PAINT_OBJECTS = 10;
	
	// Enums of Shape, Color and Filled (Makes printing the easier)
	private enum PaintableShapes {RECTANGLE, ELLIPSE, LINE}
	private enum PaintableColors {BLACK, BLUE, CYAN, GRAY, GREEN, MAGENTA, PINK, RED, ORANGE, YELLOW, WHITE}
	private enum PaintableFills {FILLED, EMPTY}
	
	// Saving the Menus for easier removal
	private JMenu shapeMenu;
	private JMenu colorMenu;
	private JMenu fillingMenu;
	
	
	// Variables holding the current selection of Shape, Color and filling 
	// (again using the enum types for easier printing)
	private PaintableShapes currentShape;
	private PaintableColors currentColor;
	private boolean currentlyFilled;
	
	// The list of Shapes that will be drawn 
	// (an ArrayList would be better but it wasn't part of the lecture yet)
	private PaintObject[] paintedObjects = new PaintObject[MAX_PAINT_OBJECTS];
	// The number of objects (e.g. can't draw null)
	private int numObjects;
	
	
	// The start and end point of a click (so we know how big our drag and our Shape is)
	private Point startPoint;
	private Point endPoint;
	
	
	public Paint(JFrame inFrame, JPanel yourPanel, Rectangle gameArea, Rectangle controlArea) {
		this.gameArea = new Rectangle(gameArea);
		this.controlArea = new Rectangle(controlArea);

		this.myPanel = yourPanel;

		tileSize = 3;
		
		this.inFrame = inFrame;
		
		// Adding a mouse Listener instead of a KeyListerner (it's pretty similar)
		this.myPanel.addMouseListener(this);

		initFullPaintGamePanel();

		inFrame.setFocusable(true); // from now on the board has the keyboard input, explicit call is needed
	}

	
	/**
	 * Here we initialize the current selection.
	 * Additionally calling addPaintJMenu() to add extra choices for Shape, Color and filling
	 */
	
	private void initFullPaintGamePanel() {
		numRows = 1;
		numColumns = 1;

		addPaintJMenu();
		
		paintArea = new Rectangle(gameArea.x + tileSize, gameArea.y + tileSize, gameArea.width - tileSize * 2,
				gameArea.height - tileSize * 2);
		
		currentShape = PaintableShapes.RECTANGLE;
		currentColor = PaintableColors.BLACK;
		currentlyFilled = true;
	}

	@Override
	public GameScores getScores() {
		return GameScores.createGameScores("Paint v.", 1);
	}

	/**
	 * Here we need to remove the extra JMenu options 
	 * (the game won't crash but it's cleaner)
	 */
	
	@Override
	public void closeGame() {
		removePaintJMenu();
		inFrame = null;
	}
	
	@Override
	public String getName() {
		return "Paint";
	}
	
	
	/*
	 * ##################################################################################################
	 * ################################### Handling the Shapes #############################�############
	 * ########## -> fuer die Lesbarkeit des Codes durch dieses Kommentar etwas abgetrennt <- ###########
	 * ##################################################################################################
	 */
	
	/**
	 * Creates an instance the currentShape
	 * 
	 * @return			the created Shape
	 */
	
	private Shape createShape() {
		switch (currentShape) {
		case ELLIPSE:
			return createAbsEllipse();
		case LINE:
			return createAbsLine();
		default:
			return createAbsRectangle();
		}
	}
	
	/**
	 * Creates a Rectangle in the space between startPoint and endPoint.
	 * Also handles the case if an end-coordinate is smaller than a start coordinate.
	 * Otherwise the Rectangle would always stretch to the bottom right of the screen.
	 * 
	 * @return			the final Ellipse
	 */
	
	private Rectangle createAbsRectangle() {
		Rectangle rect = new Rectangle(startPoint.x, startPoint.y, 
				Math.abs(endPoint.x - startPoint.x), Math.abs(endPoint.y - startPoint.y));
		
		if (endPoint.x < startPoint.x) {
			rect.x = endPoint.x;
		}
		if (endPoint.y < startPoint.y) {
			rect.y = endPoint.y;
		}
		return rect;
	}
	
	
	/**
	 * Creates an Ellipse in the space between startPoint and endPoint.
	 * Also handles the case if an end-coordinate is smaller than a start coordinate.
	 * Otherwise the Ellipse would always stretch to the bottom right of the screen.
	 * 
	 * @return			the final Ellipse
	 */
	
	private Ellipse2D.Double createAbsEllipse() {
		Ellipse2D.Double ellipse = new Ellipse2D.Double(startPoint.x, startPoint.y,
				Math.abs(endPoint.x - startPoint.x), Math.abs(endPoint.y - startPoint.y));
		
		if (endPoint.x < startPoint.x) {
			ellipse.x = endPoint.x;
		}
		if (endPoint.y < startPoint.y) {
			ellipse.y = endPoint.y;
		}
		return ellipse;
	}

	
	/**
	 * Creates a Line in the space between startPoint and endPoint.
	 * 
	 * @return			the final Ellipse
	 */
	
	private Line2D.Double createAbsLine() {
		Line2D.Double line = new Line2D.Double(startPoint, endPoint);
		return line;
	}
	
	
	/**
	 * Adds the Shape after the endPoint is known.
	 * 
	 * @param point			the end point
	 */
	
	private void finalizeShapeAt(Point point) {
		endPoint = point;
		setPositionInPaintArea(endPoint);
		addPaintedShape();
	}
	
	
	/**
	 * Adds the final Shape to the paintableObjects 
	 */
	
	private void addPaintedShape() {
		if (numObjects == paintedObjects.length) {
			shiftPaintedObjectsOneLeft();
		}
		paintedObjects[numObjects] = new PaintObject(createShape(), determineColor(), currentlyFilled);
		numObjects++;
	}
	
	
	/*
	 * ##################################################################################################
	 * ################################## Some helper functions #########################################
	 * ########## -> fuer die Lesbarkeit des Codes durch dieses Kommentar etwas abgetrennt <- ###########
	 * ##################################################################################################
	 */
	
	/**
	 * Deletes the last placed Object.
	 */
	
	private void deleteLastObject() {
		if (numObjects > 0) {
			numObjects--;
		}
		paintedObjects[numObjects] = null;
	}
	
	
	/**
	 * Sets the position inside the paint area.
	 * If we don't do that we could draw over the game info
	 * 
	 * @param pos		position to be set in bounds
	 */
	
	private void setPositionInPaintArea(Point pos) {
		// Set both x and y in range
		pos.x = forceInInterval(pos.x, paintArea.x, paintArea.width);
		pos.y = forceInInterval(pos.y, paintArea.y, paintArea.height);
	}
	
	
	/**
	 * Forces x into the interval between start and start+width. 
	 * If x is smaller than start x will be x.
	 * If x is greater than start + width x will be start + width.
	 * Else x will be returned.
	 * 
	 * @param x			number to be forced into the interval
	 * @param start		start of the interval
	 * @param width		width of the interval
	 * @return			x forced into the interval
	 */
	
	private int forceInInterval(int x, int start, int width) {
		if (x < start) {
			return start;
		} else if (x > start + width) {
			return start + width;
		}
		return x;
	}
	
	
	/**
	 * Creates the String displayed in the GameInfo.
	 * 
	 * @return			the game info string
	 */
	
	private String getShapeInfo() {
		String info = "Shape: " + currentShape + ", ";
		if (currentlyFilled) {
			info += "filled";
		}
		else {
			info += "not filed";
		}
		return info + ", Color: " + currentColor;
	}
	
	
	/**
	 * Shifts the paintedObjects one to the left (and deleting the first element).
	 * Then deleting the last object.
	 */

	private void shiftPaintedObjectsOneLeft() {
		for (int i = 1; i < paintedObjects.length; i++) {
			int nextPos = Math.floorMod(i - 1, paintedObjects.length);
			paintedObjects[nextPos] = paintedObjects[i];
		}
		deleteLastObject();
	}
	
	
	/**
	 * Determines the current (real) color.
	 * (If we wouldn't use the enum it would be harder to initialize the JMenu
	 * and print the current color)
	 * 
	 * @return			the current (java.awt.)Color
	 */
	
	private Color determineColor() {
		switch (currentColor) {
		case BLUE:
			return Color.BLUE;
		case CYAN:
			return Color.CYAN;
		case GRAY:
			return Color.GRAY;
		case GREEN:
			return Color.GREEN;
		case MAGENTA:
			return Color.MAGENTA;
		case PINK:
			return Color.PINK;
		case RED:
			return Color.RED;
		case ORANGE:
			return Color.ORANGE;
		case YELLOW:
			return Color.YELLOW;
		case WHITE:
			return Color.WHITE;
		default:
			return Color.BLACK;
		}
	}
	
	/*
	 * ##################################################################################################
	 * ############################### Methods to Paint the Board #######################################
	 * ########## -> fuer die Lesbarkeit des Codes durch dieses Kommentar etwas abgetrennt <- ###########
	 * ##################################################################################################
	 */

	/**
	 * This method paints the game area and the border.
	 * 
	 * @param g		the graphics object to paint with.
	 */
	
	public void paintGameArea(Graphics2D g) {
		g.setColor(Color.BLACK);
		g.fillRect(gameArea.x, gameArea.y, gameArea.width, gameArea.height);

		g.setColor(Color.WHITE);
		g.fillRect(paintArea.x, paintArea.y, paintArea.width, paintArea.height);
		
		paintShapes(g);
	}
	
	
	/**
	 * Painting all added shapes.
	 * 
	 * @param g		the graphics object to paint with.
	 */
	
	private void paintShapes(Graphics2D g) {
		for (int i = 0; i < numObjects; i++) {
			g.setColor(paintedObjects[i].color);
			// instanceof checks wether or not an object is an instanceof a class (or child class
			if (paintedObjects[i].shape instanceof Line2D.Double) {
				paintLine(g, paintedObjects[i]);
			} else {
				paintArea(g, paintedObjects[i]);
			}
		}
	}
	
	
	/**
	 * Painting some game info
	 * 
	 * @param g		the graphics object to paint with.
	 */
	
	public void paintControlArea(Graphics2D g) {
		g.setColor(Color.BLACK);

		g.draw(controlArea);
		
		g.drawString(getShapeInfo(), controlArea.x + 5,
				controlArea.y + controlArea.height / 3 + g.getFont().getSize() / 2);
		g.drawString("(LMB + Drag = Add Shape, RMB = Remove Shape)", controlArea.x + 5,
				controlArea.y + 2 * controlArea.height / 3 + g.getFont().getSize() / 2);
	}
	
	
	/**
	 * Fills a shape or only draws the outline using the draw() and fill() functions
	 * 
	 * @param g					the graphics object to paint with
	 * @param paintObject		the PaintObject to paint
	 */
	
	private void paintArea(Graphics2D g, PaintObject paintObject) {
		if (paintObject.filled) {
			g.fill(paintObject.shape);
		} else {
			g.draw(paintObject.shape);
		}
	}
	
	
	/**
	 * Paints a line and if the object is filled the line is bigger
	 * (Since we can't fill really a line, duh...)
	 * 
	 * @param g					the graphics object to paint with
	 * @param paintObject		the PaintObject(Line) to paint
	 */
	
	private void paintLine(Graphics2D g, PaintObject paintObject) {
		if (paintObject.filled) {
			// increasing the thickness of g => thicker line
			g.setStroke(new BasicStroke(5));
		}
		g.draw(paintObject.shape);
		//Resetting the Stroke
		g.setStroke(new BasicStroke(1));
	}

	/*
	 * ################################################################################################## 
	 * ########################### Methods to handle the relevant inputs ################################
	 * ############# Using repaint() to update the game (otherwise nothing would change) ################  
	 * ########## -> fuer die Lesbarkeit des Codes durch dieses Kommentar etwas abgetrennt <- ###########
	 * ##################################################################################################
	 */

	@Override
	public void mousePressed(MouseEvent e) {
		//Using switch here makes it easier handling other inputs later
		switch (e.getButton()) {
		case MouseEvent.BUTTON1:
			// Determine the start point of the new shape
			startPoint = e.getPoint();
			setPositionInPaintArea(startPoint);
			break;
		case MouseEvent.BUTTON3:
			// Delete the last object and repaint
			deleteLastObject();
			myPanel.repaint();
			break;
		default:
			System.out.println("Mouse Pressed: " + e + " " + e.getButton());
		}
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		//Using switch here makes it easier handling other inputs later
		switch (e.getButton()) {
		case MouseEvent.BUTTON1:
			// if the drag was completed, spawn the new object and draw it
			finalizeShapeAt(e.getPoint());
			myPanel.repaint();
		}
	}
	
	/**
	 * JMenu interactions are handled with this one below, same as in the MainGameFrame setup
	 */
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		String cmd = arg0.getActionCommand();
		for (PaintableShapes shape: PaintableShapes.values()) {
			if (shape.toString().equals(cmd)) {
				currentShape = shape;
			}
		}
		for (PaintableColors color: PaintableColors.values()) {
			if (color.toString().equals(cmd)) {
				currentColor = color;
			}
		}
		for (PaintableFills fill: PaintableFills.values()) {
			if (fill.toString().equals(cmd)) {
				currentlyFilled = cmd.equals(PaintableFills.FILLED.toString());
			}
		}
		// repaint again so the changes will be drawn
		myPanel.repaint();
	}
	
	
	/**
	 * We don't need the methods below, since we don't need such input handled
	 */
	
	@Override
	public void mouseExited(MouseEvent e) { }

	@Override
	public void mouseEntered(MouseEvent e) { }
	
	@Override
	public void mouseClicked(MouseEvent e) { }

	/*
	 * ################################################################################################## 
	 * #################### Methods for adding the menu options for drawing ############################# 
	 * ########## -> fuer die Lesbarkeit des Codes durch dieses Kommentar etwas abgetrennt <- ###########
	 * ##################################################################################################
	 */
	
	
	/**
	 * Add all three JMenus and checking if everything is aright.
	 */
	
	private void addPaintJMenu() {
		addShapeSubMenu();
		addColorSubMenu();
		addFillsSubMenu();

		inFrame.setVisible(true);
		inFrame.revalidate();
	}
	
	/**
	 * Same as in the MainGameFrame setup. We don't need to add a Shortcut
	 *  since we don't have and keyListenerimplemented
	 */
	
	private void addShapeSubMenu() {
		inFrame.setVisible(false);
		JMenuBar jmb = inFrame.getJMenuBar();
		shapeMenu = new JMenu("Shape");
		shapeMenu.setToolTipText("Here you can choose the shape you want to draw.");
		//a group of JMenuItems
		for (PaintableShapes shape: PaintableShapes.values()) {
			JMenuItem menuItem = new JMenuItem(shape.name());
			menuItem.addActionListener(this);
			shapeMenu.add(menuItem);
		}
		jmb.add(shapeMenu);
		
		inFrame.setJMenuBar(jmb);
	}
	
	private void addColorSubMenu() {
		inFrame.setVisible(false);
		JMenuBar jmb = inFrame.getJMenuBar();
		colorMenu = new JMenu("Color");
		colorMenu.setToolTipText("Here you can choose the shape you want to draw.");
		//a group of JMenuItems
		for (PaintableColors color: PaintableColors.values()) {
			JMenuItem menuItem = new JMenuItem(color.name());
			menuItem.addActionListener(this);
			colorMenu.add(menuItem);
		}
		jmb.add(colorMenu);
		
		inFrame.setJMenuBar(jmb);
	}
	
	private void addFillsSubMenu() {
		inFrame.setVisible(false);
		JMenuBar jmb = inFrame.getJMenuBar();
		fillingMenu = new JMenu("Fills");
		fillingMenu.setToolTipText("Here you can choose if the shape should be filled or not.");
		//a group of JMenuItems
		for (PaintableFills fill: PaintableFills.values()) {
			JMenuItem menuItem = new JMenuItem(fill.name());
			menuItem.addActionListener(this);
			fillingMenu.add(menuItem);
		}
		jmb.add(fillingMenu);
		
		inFrame.setJMenuBar(jmb);
	}
	
	
	/**
	 * Removes the added JMenus since we don't want nor need them in other games
	 */
	
	private void removePaintJMenu() {
		inFrame.getJMenuBar().remove(shapeMenu);
		inFrame.getJMenuBar().remove(colorMenu);
		inFrame.getJMenuBar().remove(fillingMenu);
		inFrame.revalidate();
	}
	
	/*
	 * ################################################################################################## 
	 * ############################# Class bundling Shape, Color and filling ############################
	 * ########## -> fuer die Lesbarkeit des Codes durch dieses Kommentar etwas abgetrennt <- ###########
	 * ##################################################################################################
	 */
	
	class PaintObject {
		public Shape shape;
		public Color color;
		public boolean filled;
		
		public PaintObject(Shape shape, Color color, boolean filled) {
			this.shape = shape;
			this.color = color;
			this.filled = filled;
		}
	}
}
//@author Luca Dreiling

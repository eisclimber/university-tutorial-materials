package friends;

// Eine Kindsklasse(Bus) bekommt alle Variablen und Funktionen
// der Elternklasse(hier: Car). Gekennzeichnet wird das durch 
// 'extends Car'
public class Bus extends Car {

	// Es k�nnen zus�tzliche Vaiablen
	public int persons;

	// Ein Konstruktor kann abge�ndert werden.
	public Bus(String numberPlate) {
		// super greift auf die (Methode der) Elternklasse zu
		super(numberPlate);
		persons = 1;
		// protected Variablen sind auch in den Kindsklassen
		// verfuegbar.
		weight = 100000;
		// Da serialNumber private ist haben wir hier keinen Zugriff.
		// Zum Abaendern muss der Setter verwendet werden.
		setSerialNumber((int) (Math.random() * 100));
	}

	// Hier wird eine bestehende Funktion der Elternklasse
	// ueberschrieben. Wird in einem Objekt vom Typ Bus die
	// Funktion calculateSpeed() aufgerufen, wird der Code
	// Hier ausgef�hrt. (Auf die Methode von Car kann man mit
	// super.calculateSpeed() zugreifen.
	// Als Kennzeichnung versieht man die Funktion mit
	// @Override, um die Ueberschreibung zu markieren.
	@Override
	protected double calculateSpeed() {
		// Hier rechnen wir etwas anderes
		double speed = 44;
		speed -= 0.5 * persons;
		if (speed > 0) {
			return speed;
		}
		return 0;
	}

	// Es k�nnen auch zus�tzliche Funktionen definiert werden.
	// Diese sind NICHT in der Elternklasse vorhanden.
	// Wieder serialNumber ist private, deshalb der Getter.
	public void thankManni() {
		System.out.println("Tanks Manno no. " + getSerialNumber() + "!");
	}
}

package friends;

import friends.Car.Motor;

public class Main {

	// Ein static Objekt damit wir in einem anderen Package darauf
	// zugreifen k�nnen. Wir nutzen den 2. KOnstruktor hier.
	public static Car omisAuto = new Car("MeinEnkelIstDoof");

	public static void main(String[] args) {
		// Ein paar Beispiele
		Car haraldsAuto = new Car("grau", "HaraldIstCool", 5000, 00, Motor.V12);
		Car joachimsAuto = new Car("rot", "JoachimSchnell", 1000, 121212, Motor.V12_TURBO);
		
		System.out.println("Ist Harald schneller als 45km/h? " + haraldsAuto.isFaster(45));
		System.out.println("Wie schnell ist Harald? " + haraldsAuto.calculateSpeed());
		
		System.out.println("Ist Joachim schneller als 45km/h? " + joachimsAuto.isFaster(45));
		System.out.println("Wie schnell ist Joachim? " + joachimsAuto.calculateSpeed());
		
		System.out.println("Ist Joachim schneller als 45km/h? " + omisAuto.isFaster(45));
		System.out.println("Und wie schnell ist Omi? " + omisAuto.calculateSpeed());

		Bus manni = new Bus("ManniLiebe");
		System.out.println("Ist Mannis Bus schneller als 45km/h? " + manni.isFaster(45));
		System.out.println("Und wie schnell ist Manni? " + manni.calculateSpeed());
		manni.thankManni();
	}

}

package friends;

public class Car {

	// enums sind spezielle Klassen, die Konstanten speichern und 
	// unter dem Klassennamen zusammenfassen.
	// z.B. Motor besitzt die Konstanten V12 und V12_TURBO.
	// Dabei hat die i-te Konstante den Wert i (von 0 beginnend).
	public enum Motor {
		V12, V12_TURBO
	}

	// Auf <public> Variablen kann von ueberall im Projekt zugreifen.
	// Da die Variablen nicht <static> sind sind sie objektspezifisch.
	// Das hei�t, jedes Objekt hat eine eigene Variable mit eigenem 
	// und unabhaengigem Wert (z.B. Jede Instanz vom Typ Car
	// hat eine Variable in der die Farbe des Objekts gespeichert wird). 
	public String color;

	// Auf <protected> Variablen kann im gleichen Package und in allen
	// Kindsklassen zugegriffen werden.
	// (Wieder: nicht static -> Jedes Objekt hat eine eigene Variable)
	protected long weight;
	protected String numberPlate;

	// Auf <private> Variablen kann nur innerhalb der Klasse zugegriffen
	// werden. Au�erhalb nutzt man Getter und Setter (siehe unten).
	// (Wieder: nicht static -> Jedes Objekt hat eine eigene Variable)
	private int serialNumber;

	// Die enum-Klassen k�nnen auch als (Objekt-)Typen einer Variable
	// genutzt werden.
	// z.B. motor kann entweder .V12 oder .V12_TURBO speichern.
	public Motor motor;


	// Ein Konstruktor wird beim Erstellen des Objekts aufgerufen.
	// Hier diere hier bekommt alle Werte als Parameter �bergeben bekommt.
	// Diese Werden dann in den meisten F�llen nur gesetzt.
	public Car(String color, String numberPlate, long weight, int serialNumber,
			Motor motor) {
		this.color = color;
		this.numberPlate = numberPlate;
		this.weight = weight;
		this.serialNumber = serialNumber;
		this.motor = motor;
	}

	// M�chte man Standardwerte f�r manche Variablen, kann man 
	// auf einige Parameter verzichten oder diese aendern.
	// Somit kann man hier ein Car auch zus�tzlich(!) nur mit 
	// einem String erstellen.
	// Den Vorgang nennt man Ueberschreiben (engl. Override), 
	// dabei existieren letztlich mehrere Funktionien mit dem gleichen Namen,
	// aber unterschiedlichen Parametern nebeneinander..
	public Car(String numberPlate) {
		this.color = "gray";
		this.numberPlate = numberPlate;
		this.weight = 5000;
		this.serialNumber = (int) (Math.random() * 10000) + 1;
		this.motor = Motor.V12;
	}

	// <protected>/<private>/<public> verh�lt sich bei Klassen und
	// Funktionen gleich wie bei Variablen.
	// Etwas sinnloses Rechnen.
	protected double calculateSpeed() {
		double speed = 200000 / weight;

		if (color.equals("rot")) {
			speed *= 1.5;
		}

		if (motor == Motor.V12_TURBO) {
			speed *= 2;
		}

		return speed;
	}
	
	// Da das hier <public> ist, k�nnen wir von au�erhalb
	// indirekte Schl�sse auf calculateSpeed() ziehen,
	// selbst wenn man keinen Zugriff auf die Methode hat.
	public boolean isFaster(int speed) {
		return speed < calculateSpeed();
	}

	/*
	 * Getter und Setter
	 * (erm�glichen Zugriff auf die Werte privater Variablen,
	 * aber nicht auf die Variablen selbst.)
	 */
	
	public int getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(int serialNumber) {
		this.serialNumber = serialNumber;
	}
}

package not.your.friend;

import friends.Car;

public class NotYourFriend {
	public static void main(String[] args) {	
		// Auf calculateSpeed() haben wir in einem anderen 
		// Package keinen Zugriff
		/*
		 * System.out.println(friends.main.omisAuto.calculateSpeed());
		 */
	}
}

package dynamicarrays;

import java.util.Arrays;

public class DynamicArray1 {

	// The array used for storage
	public static int[] array = new int[0];
	
	public static void main(String[] args) {
		System.out.println("Adding 5 Elements to an empty array...");
		appendElement(1);
		appendElement(3);
		System.out.println("The array after adding 2 elements: " + Arrays.toString(array));
		appendElement(5);
		appendElement(2);
		appendElement(7);
		System.out.println("The array after adding 5 elements: " + Arrays.toString(array));
		System.out.println("--------------------------------");
		System.out.println("Removing 6 Elements from an array with 5 elements...");
		popLastElement();
		popLastElement();
		popLastElement();
		popLastElement();
		System.out.println("The array after removing 4 elements: " + Arrays.toString(array));
		popLastElement();
		popLastElement();
		System.out.println("The array after removing more than the 1 remaining elements: " + Arrays.toString(array));
	}
	
	
	public static void appendElement(int elementToAdd)
	{
		// Resize Array
		int[] newArray = new int[array.length + 1];
		// Copy old values
		if (newArray.length > 1)
		{
			System.arraycopy(array, 0, newArray, 0, array.length);
		}
		// Replace old Array
		array = newArray;
		// Add element
		array[array.length - 1] = elementToAdd;
	}
	
	public static void popLastElement() {
		if (array.length > 0) {
			// Resize Array
			int[] newArray = new int[array.length - 1];
			// Copy old values, except the last one
			if (newArray.length > 0) {
				System.arraycopy(array, 0, newArray, 0, newArray.length - 1);
			}
			// Replace old array
			array = newArray;
		}
	}

}

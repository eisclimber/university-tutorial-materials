package dynamicarrays;

import java.util.Arrays;

public class DynamicArray2 {

	// The array used for storage
	public static int[] array = new int[0];
	
	// Using an index to allow default values (e.g. 0) in our array
	// If we iterated over the array we had no chance to recognize empty values
	// We also don't have to resize the array when removing elements
	// still needs the disk space though..
	public static int nextFreeIdx = 0;
	
	
	public static void main(String[] args) {
		System.out.println("Adding 5 Elements to an empty array...");
		appendElement(1);
		appendElement(3);
		System.out.println("The array after adding 2 elements: " + Arrays.toString(array));
		appendElement(5);
		appendElement(2);
		appendElement(7);
		System.out.println("The array after adding 5 elements: " + Arrays.toString(array));
		System.out.println("--------------------------------");
		System.out.println("Removing 6 Elements from an array with 5 elements...");
		popLastElement();
		popLastElement();
		popLastElement();
		popLastElement();
		System.out.println("The array after removing 4 elements: " + Arrays.toString(array));
		popLastElement();
		popLastElement();
		System.out.println("The array after removing more than the 1 remaining elements: " + Arrays.toString(array));
	}
	
	
	public static void appendElement(int elementToAdd)
	{
		// Resize Array
		int[] newArray = new int[array.length + 1];
		// Copy old values
		if (newArray.length > 1)
		{
			System.arraycopy(array, 0, newArray, 0, array.length);
		}
		// Replace old Array
		array = newArray;
		// Add element
		array[nextFreeIdx] = elementToAdd;
		nextFreeIdx++;
	}
	
	public static void popLastElement() {
		if (nextFreeIdx > 0 && array.length > 0) {
			// Decrease nextFreeIdx
			nextFreeIdx--;

			// Remove last element 
			// We actually don't need to do that if we add a get function (see next array version)
			array[nextFreeIdx] = 0;
		}
	}
}

package main;

import java.lang.reflect.Array;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// Initalizing and declaring a new array
		int[] array1 = new int[10];
		
		// Filling the array with values
		for (int i = 0; i < array1.length; i++) {
			array1[i] = i;
		}


		// Lazy evaluation -> This works (first check for valid index!)
		if (x1 < array1.length && array1[x1] > 3) {
			System.out.println(array1[x1]);
		}

		// Lazy evaluation -> This doesn't (access possible invalid index first!)
		/*	
		if (array1[x1] > 3 && x1 < array1.length) {
			System.out.println(array1[x1]);
		}
		*/

		// Initalizing and declaring a new 2d-array and filling it with values directly
		String[][] arrayTwoDee = { { "(0,0)", "(0,1)", "(0,2)" }, 
								   { "(1,0)", "(1,1)", "(1,2)" },
								   { "(2,0)", "(2,1)", "(2,2)" } };


		// 2D coordinates when evaluating
		for (int y = 0; y < arrayTwoDee.length; y++){
			for (int x = 0; x < arrayTwoDee[y].length; x++) {
				System.out.print(arrayTwoDee[y][x]);
			}
			System.out.println("");
		}

		// Double for-loop & length of "inner" array
		for (int i = 0; i < arrayTwoDee.length; i++) {
			for (int j = 0; j < arrayTwoDee[0].length; j++) {
				System.out.print(arrayTwoDee[i][j]);
			}
			System.out.println("");
		}
		
		System.out.println("");
		System.out.println("");
		

		// Print non-permuted array
		for (int i = 0; i < array1.length; i++) {
			System.out.print(array1[i] + " ");
		}
		System.out.println("");
		

		// Fisher-Yates-Shuffle
		for (int i = 0; i < array1.length; i++)
		{
			int randomIdx = (int) (Math.random() * array1.length);
			
			int temp = array1[i];
			array1[i] = array1[randomIdx];
			array1[randomIdx] = temp;
		}


		// Print shuffled array
		for (int i = 0; i < array1.length; i++) {
			System.out.print(array1[i] + " ");
		}
	}

}

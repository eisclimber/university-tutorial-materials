package main;

public class Recursion_solutions {

	public static void main(String[] args) {
		// Aufgabe 1
		System.out.println("Aufgabe 1");
		System.out.println(reverseString("Informatik"));
		System.out.println();
		
		// Aufgabe 2
		System.out.println("Aufgabe 2");
		printAscendDescend(0);
		printAscendDescend(4);
		printAscendDescend(-1);
		System.out.println();
		
		// Aufgabe 3
		System.out.println("Aufgabe 3");
		printIntArray(new int [] {1, 2, 3, 4});
		printIntArray(new int [] {1, 42, 4, 182});
		System.out.println("Aufgabe 3 (Generisch)");
		printGenericArray(new String [] {"A", "B", "C", "D"});
		printGenericArray(new String [] {"AA", "BCE", "CAX", "DAUI"});
		System.out.println();
		
		// Aufgabe 4
		System.out.println("Aufgabe 4");
		printIntArray(new int [] {1, 2, 3, 4});
		printIntArray(new int [] {1, 42, 4, 182});
		System.out.println("Aufgabe 4 (Generisch)");
		printGenericArray(new String [] {"A", "B", "C", "D"});
		printGenericArray(new String [] {"AA", "BCE", "CAX", "DAUI"});
		System.out.println();
		
		// Aufgabe 5
		System.out.println("Aufgabe 5");
		System.out.println("add(42, 0) = " + add(42, 0));
		System.out.println("add(21, 21) = " + add(21, 21));
		System.out.println();
		
		// Aufgabe 6
		System.out.println("Aufgabe 6");
		System.out.println("mult(42, 0) = " + mult(42, 0));
		System.out.println("mult(7, 6) = " + mult(7, 6));
		System.out.println();
		
		// Aufgabe 6
		System.out.println("Aufgabe 7");
		System.out.println("twoPotency(0) = " + twoPotency(0));
		System.out.println("twoPotency(-1) = " + twoPotency(-1));
		System.out.println("twoPotency(10) = " + twoPotency(10));
		System.out.println();
	}
	
	/*
	 * Aufgabe 1
	 */
	
	public static String reverseString(String toReverse) {
		return reverseStringRecursion(toReverse, toReverse.length() - 1);
	}
	
	private static String reverseStringRecursion(String toReverse, int pos) {
		if (pos < 0) {
			return "";
		}
		return toReverse.charAt(pos) + reverseStringRecursion(toReverse, pos - 1);
	}
	
	
	/*
	 * Aufgabe 2
	 */
	
	public static void printAscendDescend(int n) {
		printAscendDescendRecursion(n, 0);
		System.out.println();
	}
	
	private static void printAscendDescendRecursion(int n, int i) {
		if (i >= n) {
			System.out.print(n + ", ");
		} else {
			System.out.print(i + ", ");
			printAscendDescendRecursion(n, i + 1);
			System.out.print(i + ", ");
		}
	}
	
	
	/*
	 * Aufgabe 3
	 */
	
	public static void printIntArray(int[] toPrint) {
		printIntArrayRecursion(toPrint, 0);
		System.out.println();
	}
	
	public static void printIntArrayRecursion(int[] toPrint, int pos) {
		System.out.print(toPrint[pos] + ", ");
		if (pos < toPrint.length - 1) {
			printIntArrayRecursion(toPrint, pos + 1);
		}
	}
	

	/*
	 * Aufgabe 3 (Generisch)
	 */
	
	public static <T> void printGenericArray(T[] toPrint) {
		printGenericArrayRecursion(toPrint, 0);
		System.out.println();
	}
	
	public static <T> void printGenericArrayRecursion(T[] toPrint, int pos) {
		System.out.print(toPrint[pos].toString() + ", ");
		if (pos < toPrint.length - 1) {
			printGenericArrayRecursion(toPrint, pos + 1);
		}
	}
	
	
	/*
	 * Aufgabe 4
	 */
	
	public static void printIntArrayReversed(int[] toPrint) {
		printIntArrayRecursionReversed(toPrint, toPrint.length);
		System.out.println();
	}
	
	public static void printIntArrayRecursionReversed(int[] toPrint, int pos) {
		System.out.print(toPrint[pos] + ", ");
		if (pos > 0) {
			printIntArrayRecursionReversed(toPrint, pos - 1);
		}
	}
	

	/*
	 * Aufgabe 4 (Generisch)
	 */
	
	public static <T> void printGenericArrayReversed(T[] toPrint) {
		printGenericArrayRecursionReversed(toPrint, toPrint.length);
		System.out.println();
	}
	
	public static <T> void printGenericArrayRecursionReversed(T[] toPrint, int pos) {
		System.out.print(toPrint[pos].toString() + ", ");
		if (pos > 0) {
			printGenericArrayRecursionReversed(toPrint, pos - 1);
		}
	}
	
	
	/*
	 * Aufgabe 5
	 */
	
	public static int add(int a, int b) {
		if (b <= 0) {
			return a;
		}
		// In-/Dekrementationen am Besten immer als einzelne Zeile
		a++;
		b--;
		return add(a, b);
	}
	
	
	/*
	 * Aufgabe 5
	 */
	
	public static int mult(int a, int b) {
		if (a <= 0 || b <= 0) {
			return 0;
		} else if (a == 1) {
			return b;
		} else if (b == 1) {
			return a;
		}
		// In-/Dekrementationen am Besten immer als einzelne Zeile
		b--;
		return add(a, mult(a, b));
	}
	
	
	/*
	 * Aufgabe 7
	 */
	
	public static int twoPotency(int n) {
		if (n <= 0) {
			return 1;
		} else if (n == 1) {
			return 2;
		}
		n--;
		return mult(2, twoPotency(n));
	}
}

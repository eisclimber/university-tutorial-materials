package gamepackage;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;

public class GridGameTools {

	/**
	 * Determines in which area the specified location is located.
	 * 
	 * @param x
	 *            x location
	 * @param y
	 *            y location
	 * @return 0,1,... for the respectively ordered areas,
	 *         -1 otherwise.
	 */
	public static int containedInWhichArea(int x, int y, Rectangle... areas) {
		for(int i=0; i<areas.length; i++)
		{
			if (x > areas[i].x && x < areas[i].x + areas[i].width && y > areas[i].y
				&& y < areas[i].y + areas[i].height)
			return i;
		}		
		return -1;
	}
	
	public static void drawSquare(Graphics2D g, int x, int y, Color color, int tileSize)
	{
		drawFilledRect(g, x, y, tileSize, tileSize, color);
	}

	public static void drawFilledRect(Graphics2D g, int x, int y, int width, int height, Color color)
	{
		g.setColor(color);
		g.fillRect(x + 1, y + 1, width-2, height-2);

		g.setColor(color.brighter());
		g.drawLine(x, y + height - 1, x, y);
		g.drawLine(x, y, x + width - 1, y);

		g.setColor(color.darker());
		g.drawLine(x + 1, y + height - 1,
				x + width - 1, y + height - 1);
		g.drawLine(x + width - 1, y + height - 1,
				x + width - 1, y + 1);

	}


}

package main;

public class Main {

	public static final double PI = 3.14159265359f;
	public static final int THE_ANSWER = 42;
	
	enum DIRECTION {
		UP,
		DOWN,
		LEFT,
		RIGHT;
	}
	
	public static String[] groceries = new String[] { "Apples", "Oranges", "More Apples" };
	
	
	public static void main(String[] args) {
		System.out.println("Printing two lists that showcase different were to use lazy iteration or not: ");
		printGroceriesNumberList();
		System.out.println();
		printGroceriesBulletList();
		
		System.out.println();
		System.out.println();
		
		System.out.println("Printing all Directions with their name and their (int)value: ");
		printEnumValues();
		
		System.out.println();
		System.out.println();
		
		System.out.println("Calling a void method with paramters (r = 2)");
		printCircumference(2);
		System.out.println("Using the a non-void method to store the result of our calulations in a variable");
		double radius = calculateCircumference(2);
		System.out.println("We can use the return type as normal variable (e.g. calulate radius * 2 / 2): " + (radius * 2 / 2));
		
		System.out.println();
		
		System.out.println("Same works with multiple parameters (a = 4, b = 2)");
		printRectArea(4, 2);
		double rectArea = calculateRectArea(4, 2);
		System.out.println("We can use the return type as again normal variable (e.g. calulate rectArea * 2 / 2): " + (rectArea * 2 / 2));
		
		
		System.out.println();
		System.out.println();
		
		System.out.println("Guessing the worng answer(24), it was : " + isGuessTheAnswer(24));
		System.out.println("Guessing the rightanswer (42), it was : " + isGuessTheAnswer(42));
		
	}
	
	
	public static void printGroceriesNumberList() {
		// We need no information about the index -> Lazy evaluation!
		for (String item : groceries) {
			System.out.println(" - " + item);
		}
	}
	
	public static void printGroceriesBulletList() {
		// We NEED information about the index -> "Regular" for-loop
		for (int i = 0; i < groceries.length; i++) {
			System.out.println((i + 1) + ". " + groceries[0]);
		}
		
		/*
		* // Don't do that!
		* int i = 0;
		* for (String item : groceries) {
		* 	System.out.println((i + 1) + ". " + item);
		* 	i++;
		* }
		* */
	}
	

	public static void printEnumValues() {
		for (DIRECTION value : DIRECTION.values()) {
			System.out.print(value.name() + " " + value.ordinal() + "\n");
		}
	}
	
	
	/*
	 *  Some Basic funtions with `void`-Type
	 */
	public static void printTheAnswer() {
		System.out.println("42");
	}
	
	private static void printTheQuestion() {
		System.out.println("I think the problem, to be quite honest with you, is that you've never actually known what the question is.");
	}
	
	
	/*
	 *  Functions can have (multiple) parameters and return actual values
	 */
	public static void printCircumference(double r) {
		System.out.println("The circumference is: " + (PI * r));
	}
	
	public static double calculateCircumference(double r) {
		return PI * r;
	}	
	
	public static void printRectArea(double a, double b) {
		System.out.println("The rectangle area is: " + (a * b));
	}
	
	public static double calculateRectArea(double a, double b) {
		return a * b;
	}
	
	/*
	 * Functions with return types must return values at all possible paths
	 */
	public static boolean isGuessTheAnswer(int guessedAnswer) {
		// !!!!!!!!!!!!!!!!!!!!!!!!
		// This is actually very bad code as we could just write `return (guessedAnswer == THE_ANSWER);`
		if (guessedAnswer == THE_ANSWER) {
			return true;
		}
		else if (guessedAnswer < THE_ANSWER || guessedAnswer > THE_ANSWER) {
			return false;
		}
		// Even though we are checking every value in of guessedAnswer in our if-else-statement,
		// we must still return something here. Java isn't as smart as we are:D
		// we could use an else-case but we can also just write a return (since we return something in all of the if-statements`)
		return false;
	}
}

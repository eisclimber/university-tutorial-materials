package main;

public interface ISmartScience {
	
	/**
	 * Does some science stuff
	 */
	public void doScience();
	
}

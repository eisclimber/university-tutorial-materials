package main;

public class RickrollException extends Exception {

	// Since Exceptions are implement the Serializable-Interface they need a value for this
	// It is used for Serialization (reading & writing whole classes from/to the file system)
	// acting as a version number to check for compatibility
	private static final long serialVersionUID = -6192085729515853460L;

	// Parameterless Constructor -> no Custom message
	public RickrollException() { }

	// Constructor that accepts a message
	public RickrollException(String message) {
		super("You go rick rolled: " + message);
	}

}

package main;

public class MortyReader extends ABasicReader {

	/**
	 * Morty's implementation of validateFile.
	 */
	public boolean validateFile(String filePath) {
		try {
			String contents = readFileAt(filePath);
			System.out.println("Morty: Uhmm.. ohhh..");
			System.out.println(contents);
			return true;
		} catch (Exception e) {
			if (e instanceof RickrollException) {
				System.out.println("Morty: Never gonna give... Ahhhhh damn...");
			} else {
				e.printStackTrace();
			}
		}

		return false;
	}

}

package main;

public class RickReader extends ABasicReader implements ISmartScience {

	// Every Rick has a Morty
	private MortyReader morty;

	/**
	 * Constructors (for convenience and to make Morty private)
	 */
	public RickReader() {
		System.out.println("Getting a new Morty.");
		morty = new MortyReader();
	}

	public RickReader(MortyReader morty) {
		System.out.println("Getting an used Morty...");
		this.morty = morty;
	}

	/**
	 * Rick's implementation of validateFile.
	 */
	public boolean validateFile(String filePath) {
		try {
			String contents = readFileAt(filePath);
			System.out.println("Rick:");
			System.out.println(contents);
		} catch (Exception e) {
			if (e instanceof RickrollException) {
				System.out.println("Rick: Here Morty, this one's for you! \n");

				return morty.validateFile(filePath);
			} else {
				e.printStackTrace();
			}
		}
		return false;
	}

	@Override
	public void doScience() {
		if (Math.random() < 0.5f) {
			System.out.println("Rick: Some Pickle Rick Science!");
		} else {
			System.out.println("Rick: Here Morty a science experiment.");
			System.out.println("Morty: *BOOM* Ouch!!");
			System.out.println("Rick: Hehehe");
		}

	}

}

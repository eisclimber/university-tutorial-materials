package main;

public class Main {

	public static void main(String[] args)
	{
		MortyReader morty = new MortyReader();
		
		RickReader rick = new RickReader(morty);
		
		rick.doScience();
		
		System.out.println();
		
		// Relative Path (Using Unix Syntax -> '/')
		morty.validateFile("./resources/TestText1.txt"); 
		
		System.out.println("-----------------------------------------------------");
		// Relative path (automatically imply root './')
		rick.validateFile("resources/TestText1.txt");
		System.out.println("-----------------------------------------------------");
		// Relative Path using '..' going back to previous
		rick.validateFile("./resources/../resources/TestText2.txt"); 
		System.out.println("-----------------------------------------------------");
		// Relative path use Windows backslash syntax -> '\' (backslashes must be escaped -> '\\')
		rick.validateFile(".\\resources\\TestText3.txt");
		System.out.println("-----------------------------------------------------");
		// Absolute path starting from your hard drive
		// Everything else applies, slashes can be exchanged with double backslashes
		// !!! Must be an actual path on your own pc !!!!
		rick.validateFile("C:/Users/Luca/eclipse-workspace/RickAndMortyFileIO/resources/TestText3.txt");
	}
}

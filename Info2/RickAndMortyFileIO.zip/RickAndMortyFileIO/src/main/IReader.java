package main;

import java.io.IOException;

public interface IReader {
	
	/**
	 * Reads a file and returns it's contents as String.
	 * 
	 * @param filePath				The path to the file. Can be either absolute or relative (Windows or Unix).
	 * @return						The contents of the file.
	 * @throws IOException			If the file is not found or cannot be opened.
	 * @throws RickrollException	If the file contains part of Rick Astley's song 'Never Gonna Give You Up'.
	 */
	public String readFileAt(String filePath) throws IOException, RickrollException;
	
}

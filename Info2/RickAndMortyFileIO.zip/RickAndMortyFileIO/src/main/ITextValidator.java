package main;

public interface ITextValidator {
	
	/**
	 * Validates a file by parsing it's contents. Rick and Morty just print the text.
	 * 
	 * @param filePath		The path to the file. Can be either absolute or relative (Windows or Unix).
	 * @return				If the validation was successful.
	 */
	public boolean validateFile(String filePath);
	
}

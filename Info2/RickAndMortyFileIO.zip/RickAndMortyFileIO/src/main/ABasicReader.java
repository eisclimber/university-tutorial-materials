package main;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;

public abstract class ABasicReader implements IReader, ITextValidator {

	public String readFileAt(String filePath) throws IOException, RickrollException {

		InputStream inputStream = null;

		String res = "";
		try (BufferedReader buffReader = new BufferedReader(new FileReader(filePath))) {
			// Read each line
			while (buffReader.ready()) {
				res += buffReader.readLine() + "\n";
			}
			// Read each character
//			while (buffReader.ready()) {
//				res += buffReader.read();
//			}

			// Can't throw the RickrollException here as it gets 'caught' by the surrounding try-catch-block
//			if (res.contains("Never gonna give you up")) {
//				throw new RickrollException();
//			}
		}

		catch (Exception e) {
			// We don't need to write 'e.printStackTrace();'. Instead we can write something on our own
			// Check out String.format() on your own, it's a great 'construct':D
			System.err.println(String.format("Where did they put the file at '%s' again???", filePath));
			e.printStackTrace();
		} finally {
			// Always close streams!
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		// Check for Rickrolls here
		if (res.contains("Never gonna give you up")) {
			throw new RickrollException();
		}

		return res;

	}

}

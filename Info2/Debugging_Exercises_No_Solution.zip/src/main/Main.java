package main;

import java.util.Arrays;

public class Main {

	public static void main(String[] args) {
		// Your tests here
	}
	
	/* *************************************************************************************
	 * 								      Task 1                                           *
	 *                                                                                     *
	 *            The method `intArrayToHexString` does not work, fix it!                  *
	 *                                                                                     *  
	 * *************************************************************************************/
	
	/**
	 * Converts an array of integers into a string it's hexadecimal representation
	 * 
	 * @param array			The integer array to be converted to hexadecimal string
	 * @return				The hexadecimal string representation of the integer array
	 */
	public static String intArrayToHexString(int[] array)
	{
		String res = "";
		if (array.length <= 1) {
			res = "" + toSingleHexDigit(array[0]);
		}
		else if (array.length > 1) {
			String res1 = "";
			for (int i = 0; i < array.length - 1; i++)
			{
				res1 += toSingleHexDigit(array[i]);
			}
		}
		return res;
	}
	
	/**
	 * Converts an integer into a character representing the integer's value in hexadecimal.
	 * 
	 * Note: Hexadecimal values are:
	 * 	  0 = '0'
	 * 	  1 = '1'
	 *    2 = '2'
	 *    3 = '3'
	 *    4 = '4'
	 *    5 = '5'
	 *    6 = '6'
	 *    7 = '7'
	 *    8 = '8'
	 *    9 = '9'
	 *   10 = 'A'
	 *   11 = 'B'
	 *   12 = 'C'
	 *   13 = 'D'
	 *   14 = 'E'
	 *   15 = 'F'
	 * 
	 * @param value			The value to be represented as hexadecimal digit	
	 * @return				The value as hexadecimal digit or '#' if not possible
	 */
	public static char toSingleHexDigit(int value) {
		/*
		 * Characters are basically also only (ASCII-encoded) numbers.
		 * Thus in Java we can simply add a character to an integer 
		 * (e.g. the char 'A' equals the integer 65. The *char(!!)* '0' equals the integer 48)
		 * To get a character back we cast the integer explicit as char.
		 * ASCII table: https://alpharithms.s3.amazonaws.com/assets/img/ascii-chart/ascii-table-alpharithms-scaled.jpg
		 */
		if (value < 10) {
			return (char) (value + '0');
		}
		return (char) (value + 'A');
	}
	
	
	/* *************************************************************************************
	 * 								      Task 2                                           *
	 *                                                                                     *
	 *   Somehow none of the community members gets the right amount of money. Fix it!!!   *
	 *                                                                                     *  
	 * *************************************************************************************/
	
	
	/**
	 * This function divides the (positive) price money of a lottery *evenly* between all participants
	 * of a betting community AND as the betting community's manager.
	 * The price money, the community's new balances as well as manager's share will be printed.
	 * 
	 * @param priceMoney			The money they won
	 * @param communityBalances		The account balances of members of the betting community
	 * @param managerBalance		The account balance of the betting community's manager
	 */
	public static void splitPriceMoney(int priceMoney, float[] communityBalances, float managerBalance) {
		if (communityBalances.length <= 0)
		{
			System.out.println();
		}
		float share = (priceMoney / (communityBalances.length + 1));
		
		for (float balance : communityBalances) {
			balance += share;
		}
		
		// Return the remaining value of the price money, e.g. the last share
		managerBalance += Math.abs(share) - (share * communityBalances.length);

		System.out.println("The community won: " + priceMoney);
		System.out.println("The manager has gotten a share of: " + share);
		System.out.println("Their new account balances are now: " + Arrays.toString(communityBalances));
	}
	
	
	/* *************************************************************************************
	 * 								      Task 3                                           *
	 *                                                                                     *
	 *        You are an international renowed wildlife researcher that visits             *
	 *            and scores reservations based on the animals they shelter.               *
	 *      Your goal is to calculate a score based on the animals in that reservation     *
	 *                  but your current approach does not work properly.                  *
	 *                          Fix it! (but keep the switch)                              *
	 *                                                                                     *  
	 * *************************************************************************************/

	enum ANIMAL {
		RABBIT,
		EMU,
		ANTELOPE,
		ZEBRA,
		RHINO,
		HONSE, // https://www.youtube.com/watch?v=WWajPgrr0Ng&ab_channel=Mistergreencheese
		UNICORN,
		I_HAVE_NO_IDEA_WHICH_ANIMAL_THIS_IS
	}
	
	
	/**
	 * Sums up all the scores of animals in a reservation.
	 * 
	 * @param animals			The reservation represented as array of ANIMAL
	 * @return					The integer score of the reservation
	 */
	public static int getReservationScore(ANIMAL[] animals)
	{
		int score = 0;
		for (ANIMAL animal : animals) {
			switch (animal) {
				case RABBIT: case EMU:
					score += 3;
				case UNICORN:
					// Can't beat a unicorn -> Return best value directly
					return Integer.MIN_VALUE; 
				case ANTELOPE: case ZEBRA:
					score += 5;
				case RHINO:
					score = 10;
					break;
				case HONSE:
					score += 100;
					break;
				default:
					score += 1;
			}
		}
		return score;
	}
	
	
	/* *************************************************************************************
	 * 								      Task 4                                           *
	 *                                                                                     *
	 *        Your favorite college finished some code just before the end work...         *
	 *            The core (somehow) works, it but does not perform well...                *
	 *             Your colleague also forgot what it was supposed to do.                  *
	 *          Figure out what it is doing and improve/rewrite the code.                  *
	 *                                                                                     *  
	 * *************************************************************************************/
	
	/**
	 * 
	 * @param a
	 * @return
	 */
	public static int[] s(int[] a) {
		int l = a.length;
		boolean[] b = new boolean[l];{
		if (l <= 0) { return a; } 
			int[] a2 = new int[l];
		
			for (int i = l - 1; i >= 0; i--) {
				int n = (int) (Math.random() * l);
				while (b[n] != false) {
					n = (int) (Math.random() * l);}
				a2[i] = a[n];
				b[n] = b[n] || !b[n];
			}
		
		return a2;
		}
	}
}

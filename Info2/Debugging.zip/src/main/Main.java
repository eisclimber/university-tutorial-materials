package main;

import java.util.Arrays;

public class Main {

	public static void main(String[] args) {
		// Your tests here
	}
	
	/* *************************************************************************************
	 * 								      Task 1                                           *
	 *                                                                                     *
	 *            The method `intArrayToHexString` does not work, fix it!                  *
	 *                                                                                     *  
	 * *************************************************************************************/
	
	/**
	 * Converts an array of integers into a string it's hexadecimal representation
	 * 
	 * @param array			The integer array to be converted to hexadecimal string
	 * @return				The hexadecimal string representation of the integer array
	 */
	public String intArrayToHexString(int[] array)
	{
		String res = "";
		if (array.length <= 1) {
			res = "" + toSingleHexDigit(array[0]);
		}
		else if (array.length > 1) {
			String res1 = "";
			for (int i = 0; i < array.length - 1; i++)
			{
				res1 += toSingleHexDigit(array[i]);
			}
		}
		return res;
	}
	
	/**
	 * Converts an integer into a character representing the integer's value in hexadecimal.
	 * 
	 * Note: Hexadecimal values are:
	 * 	  0 = '0'
	 * 	  1 = '1'
	 *    2 = '2'
	 *    3 = '3'
	 *    4 = '4'
	 *    5 = '5'
	 *    6 = '6'
	 *    7 = '7'
	 *    8 = '8'
	 *    9 = '9'
	 *   10 = 'A'
	 *   11 = 'B'
	 *   12 = 'C'
	 *   13 = 'D'
	 *   14 = 'E'
	 *   15 = 'F'
	 * 
	 * @param value			The value to be represented as hexadecimal digit	
	 * @return				The value as hexadecimal digit or '#' if not possible
	 */
	public char toSingleHexDigit(int value) {
		/*
		 * Characters are basically also only (ASCII-encoded) numbers.
		 * Thus in Java we can simply add a character to an integer 
		 * (e.g. the char 'A' equals the integer 65. The *char(!!)* '0' equals the integer 48)
		 * To get a character back we cast the integer explicit as char.
		 * ASCII table: https://alpharithms.s3.amazonaws.com/assets/img/ascii-chart/ascii-table-alpharithms-scaled.jpg
		 */
		if (value < 10) {
			return (char) (value + '0');
		}
		return (char) (value + 'A');
	}
	
	
	/* *************************************************************************************
	 * 								      Task 2                                           *
	 *                                                                                     *
	 *   Somehow none of the community members gets the right amount of money. Fix it!!!   *
	 *                                                                                     *  
	 * *************************************************************************************/
	
	
	/**
	 * This function divides the (positive) price money of a lottery *evenly* between all participants
	 * of a betting community AND as the betting community's manager.
	 * The price money, the community's new balances as well as manager's share will be printed.
	 * 
	 * @param priceMoney			The money they won
	 * @param communityBalances		The account balances of members of the betting community
	 * @param managerBalance		The account balance of the betting community's manager
	 */
	public static void splitPriceMoney(int priceMoney, float[] communityBalances, float managerBalance) {
		if (communityBalances.length <= 0)
		{
			System.out.println();
		}
		float share = (priceMoney / (communityBalances.length + 1));
		
		for (float balance : communityBalances) {
			balance += share;
		}
		
		// Return the remaining value of the price money, e.g. the last share
		managerBalance += Math.abs(share) - (share * communityBalances.length);

		System.out.println("The community won: " + priceMoney);
		System.out.println("The manager has gotten a share of: " + share);
		System.out.println("Their new account balances are now: " + Arrays.toString(communityBalances));
	}
	
	
	/* *************************************************************************************
	 * 								      Task 3                                           *
	 *                                                                                     *
	 *        You are an international renowed wildlife researcher that visits             *
	 *            and scores reservations based on the animals they shelter.               *
	 *      Your goal is to calculate a score based on the animals in that reservation     *
	 *                  but your current approach does not work properly.                  *
	 *                          Fix it! (but keep the switch)                              *
	 *                                                                                     *  
	 * *************************************************************************************/

	enum ANIMAL {
		RABBIT,
		EMU,
		ANTELOPE,
		ZEBRA,
		RHINO,
		HONSE, // https://www.youtube.com/watch?v=WWajPgrr0Ng&ab_channel=Mistergreencheese
		UNICORN,
		I_HAVE_NO_IDEA_WHICH_ANIMAL_THIS_IS
	}
	
	
	/**
	 * Sums up all the scores of animals in a reservation.
	 * 
	 * @param animals			The reservation represented as array of ANIMAL
	 * @return					The integer score of the reservation
	 */
	public static int getReservationScore(ANIMAL[] animals)
	{
		int score = 0;
		for (ANIMAL animal : animals) {
			switch (animal) {
				case RABBIT: case EMU:
					score += 3;
				case UNICORN:
					// Can't beat a unicorn -> Return best value directly
					return Integer.MIN_VALUE; 
				case ANTELOPE: case ZEBRA:
					score += 5;
				case RHINO:
					score = 10;
					break;
				case HONSE:
					score += 100;
					break;
				default:
					score += 1;
			}
		}
		return score;
	}
	
	
	/* *************************************************************************************
	 * 								      Task 4                                           *
	 *                                                                                     *
	 *        Your favorite college finished some code just before the end work...         *
	 *            The core (somehow) works, it but does not perform well...                *
	 *             Your colleague also forgot what it was supposed to do.                  *
	 *          Figure out what it is doing and improve/rewrite the code.                  *
	 *                                                                                     *  
	 * *************************************************************************************/
	
	/**
	 * 
	 * @param a
	 * @return
	 */
	public static int[] s(int[] a) {
		int l = a.length;
		boolean[] b = new boolean[l];{
		if (l <= 0) { return a; } 
			int[] a2 = new int[l];
		
			for (int i = l - 1; i >= 0; i--) {
				int n = (int) (Math.random() * l);
				while (b[n] != false) {
					n = (int) (Math.random() * l);}
				a2[i] = a[n];
				b[n] = b[n] || !b[n];
			}
		
		return a2;
		}
	}
	
	
	
	/*************************************
	 *			  Solutions              * 
	 *************************************/
	
	/*
	 * Task 1:
	 * 
	 * toSingleHexDigit 
	 * - Should not work with values  <0 or >= 16.
	 * 		-> Check how to handle it (depends on the application, e.g. return a space or throw an exception)
	 *  
	 *  intArrayToHexString:
	 *  - The if-statement is unnecessary and may cause an error if the length of the array is < 0 as array[0] will be accessed
	 *  - res1 is unused so the values stored in it will not be used. It may have been accidentally created and confused with res.
	 *  - The loop will exit one element too early as it only runs for `i < array.length - 1`
	 */
	
	/*
	 * Task 2:
	 * 
	 * - The variable `balance` which is created for the Lazy-Iteration is *independent* of the value in `communityBalances[i]`
	 * 		Meaning: Altering the value of  `balance` will NOT alter the balance at `communityBalances[i]`
	 * - The `share` is calculated using an integer division (both `priceMoney` and  `(communityBalances.length + 1)` are integer)
	 * 		So the returned value will be an integer which is implicit converted to an float.
	 * 		The value after the floating point thus will be truncated (-> community members get less than they deserve)
	 * - The manager wants to be smart and calculates the last share as the value the remaining value of the price pool.
	 * 		Since the `share`is not calculated properly, this will be more money than the manager's share. 
	 * - As there are no checks if the price money is negative, as the `share` will be negative the participants will loose money. 
	 * 		This is especially devious as the manager will then receive the amount deducted from the other balances 
	 * 		due to it's calculations of their share.
	 */
	
	
	/*
	 * Task 3:
	 * 
	 * - In case of an UNICORN the minimal value is returned instead of the maximal value
	 * - Both the statements for the cases (RABBIT & EMU) and (ANTELOPE &  ZEBRA) are missing a `break;`
	 * 		so the following following cases will be also executed (until hitting a `break;`)
	 * - The case RHINO sets the value of `score` to 10 instead of adding 10 to it
	 */
	
	
	/*
	 * Task 4:
	 * 
	 * - The code shuffles the array `a` randomly. It does that by randomly selecting an index `n` (which was not used already) 
	 * 		for each element and moving that array to that index in the return array.
	 * - The code is basically unreadable as there is no formating, code redundancy, meaningless variable names, no commenting, ...
	 * - The inefficiency comes from the probability of selecting an index that has not been used before. 
	 * 		Using an index `n` will reduce the probability for finding the next valid index by (1 / array.length).
	 * 		E.g. for an array with length 100. The last element will be chosen with probability (1%)
	 * - It it is too messy (or a simple thing gets too complex) it may be best to scrap it and start over
	 * 		E.g. Use a Fisher-Yates-Shuffle instead.
	 */
}

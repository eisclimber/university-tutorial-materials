package main;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class Main {
	
	public static void main(String[] args) {
		// Create List and Set. We can use the "Diamond"-operator (<>) for initialization
		ArrayList<Integer> myList = new ArrayList<>();
		HashSet<Integer> mySet = new HashSet<>();
		// Queue is a Interface for Collections, 
		// that means a simple "LinkedList" can be used
		Queue<Integer> myQueue = new LinkedList<>();
		// Stack is already a class, so we have to create one using it's constructor
		Stack<Integer> myStack = new Stack<>();
		
		// Add some elements to myList
		myList.add(7);
		myList.add(1);
		myList.add(2);
		myList.add(3);
		myList.add(2);
		myList.add(47);
		myList.add(74);
		myList.add(7);
		myList.add(2);
		
		// Remove the element at idx = 5, list shrinks automatically
		myList.remove(5); 
		// Remove the *first* element with value 74. Index must be checked for validity
		int removeIdx = myList.indexOf(74);
		if (removeIdx >= 0) {
			myList.remove(myList.indexOf(74));
		}
		
		
		// Compared to arrays, these collections (lists) can be printed pretty
		System.out.println(myList.toString());
		
		// Add elements from myList to the other list-structures
		for (Integer i : myList) {
			// Add only new elements to the Stack and Queue
			if (!mySet.contains(i)) {
				myStack.push(i);
				myQueue.add(i);
			}
			// No need to check if an element is already in mySet (since it's a set)
			mySet.add(i);
		}
		// Print elements in mySet
		System.out.println("Elements in mySet: " + mySet.toString());
		
		
		// Remove all items from the stack
		System.out.println("Stack initially: " + myStack.toString());
		while (!myStack.empty()) {
			System.out.println("Removed: " + myStack.pop() + " Rest: " + myStack.toString());
		}
		
		// Remove all items from the queue
		System.out.println("Q initially: " + myQueue.toString());
		while (myQueue.size() > 0) {
			System.out.println("Removed: " + myQueue.poll() + " Rest: " + myQueue.toString());
		}
		
		System.out.println();
		
		
		/////////////////////////
		// Create & Populate Lists for our generic class
		LinkedList<Integer> myIntList = new LinkedList<>();
		// Either add all from a list
		myIntList.addAll(myList);
		// Or create new list from an array
		LinkedList<Boolean> myBooleanList = new LinkedList<>(Arrays.asList(new Boolean[] {true, false, true, true, false}));
		
		
		// Create instances from own Class		
		GenericClass<Double, LinkedList<Integer>> myGenericInstance1 = new GenericClass<>(42.0, myIntList);
		GenericClass<String, LinkedList<Boolean>> myGenericInstance2 = new GenericClass<>("Ello", myBooleanList);
		
		// Test .foo()-function (123d will be cast to double, because of the "d")
		System.out.println(myGenericInstance1.foo(123d, new LinkedList<Integer>(Arrays.asList(new Integer[] {1, 8, 2}))).toString());
		
		System.out.println();
		
		// Test .bar()-function with implicit parameters for Q
		myGenericInstance1.bar(2); // Integer
		myGenericInstance1.bar(2f); // Float
		myGenericInstance1.bar(2.0); // Double
		myGenericInstance1.bar("2 String"); // String
		myGenericInstance1.bar(new String("2 String")); // String
		
		System.out.println();
		
		// Also works for myGenericInstance2
		myGenericInstance2.bar(3);
		
	}
}

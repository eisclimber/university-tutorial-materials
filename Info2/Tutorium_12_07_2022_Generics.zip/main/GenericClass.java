package main;

import java.util.Collection;

public class GenericClass<S, T extends Collection<?>> {
	//                    ^ Defines arbitrary generic type for the class
	// 
	// 					     ^ Defines a generic type for the class but requires 
	// 						it to be an arbitrary collection.
	//
	// S and T may be different to each other and can be used in the whole class

	S valueS;
	T valueT;
	
	
	// Constructor
	public GenericClass(S valueS, T valueT) {
		this.valueS = valueS;
		this.valueT = valueT;
	}
	
	
	// Use T like a "normal" type 
	public T foo(S value1, T value2) {
		return value2;
	}
	
	// Create new generic Type "Q" for this method exclusively!
	// The type of the type will be derived from the parameters passed in
	public <Q> void bar(Q valueQ) {
		System.out.println(valueS.toString() + " " + valueT.toString() + " " + valueQ.toString());
	}
}

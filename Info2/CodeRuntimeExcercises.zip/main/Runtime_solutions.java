package main;

import java.util.Arrays;

public class Runtime_solutions {
	
	// Geben sie die Worst-Case-Laufzeit (in Abh�ngigkeit von data.length) an
	// Schreiben sie method1 als for-Schleife ohne "for (int i: data)" zu nutzen,
	// als while- und do-while-Schleife
	public static int method0(int[] data) {
		int result = 0;
		for (int i: data) {
			result += i;
		}
		return result;
	}
	
	/* Solution
	public static int method0_for(int[] data) {
		int result = 0;
		for (int i = 0; i < data.length; i++) {
			result += data[i];
		}
		return result;
	}
	
	public static int method0_while(int[] data) {
		int result = 0;
		int i = 0;
		while (i < data.length) {
			result += data[i];
			i++;
		}
		return result;
	}
	
	public static int method0_doWhile(int[] data) {
		int result = 0;
		int i = 0;
		do {
			if (data == null || data.length == 0) {
				return result;
			}
			
			result += data[i];
			i++;			
		} while (i < data.length);
		return result;
	}
	
	Laufzeit: �ber das gesammte Array wird ein Mal iteriert => in O(n)
	*/
	
	// Geben sie die Worst-Case-Laufzeit an 
	public static int method1(int n) {
		int result = 0;
		for (int i = n; n >= 0; i--) {
			result += i;
		}
		return result;
	}
	
	/*
	 * Laufzeit: �ber das gesammte Array wird ein Mal (r�ckw�rts) iteriert => in O(n)
	 */
	
	// Geben sie die Worst-Case-Laufzeit und das Ergebnis der Funktion an 
	public static int method2(int n) {
		n = 10;
		return method1(n);
	}
	
	/*
	 * Laufzeit: F�r jedes n wird method1() mit n = 10 aufgerufen. Somit ist die Laufzeit konstant => in O(1)
	 * Ergebnis: method1() berechent die Summe von 1 bis n-1, also berechnet method2() die von 1 bis 9 = 45
	 */
	
	// Geben sie die Worst-Case-Laufzeit an 
	public int method3(int n) {
		int result = 0;
		for (int i = 0; i < n; i++) {
			method1(i);
		}
		return result;
	}
	
	/*
	 * Laufzeit: Es wird n Mal method1() mit i aufgerufen. 
	 *  Da immer i<n sch�tzen wir die Laufzeit von method1(i) nach oben mit O(n) ab.
	 *  (sum(0) +...+ sum(n-1) <= sum(n) +...+ sum(n-1))
	 *  Somit ergibt sich n * O(n) => in O(n^2)
	 */
	
	
	// Geben Sie die Worst-Case-Laufzeit und das Ergebnis f�r n=10
	public static int method4(int n) {
		int result = 0;
		for (int i = 0; i < n; i++)
			i++;
			result += n;
		return result;
	}
	
	/*
	 * Laufzeit: Die Schleife wird n Mal aufgerufen => in O(n)
	 * Ergebnis: Aufgrund der fehlenden geschweiften Klammer der for-Schleife,
	 *  wird result += n nicht bei jedem Schleifendurchlauf aufgerufen.
	 *  Nach der Schleife wird ein Mal result += n gerechnet, somit ist result = n = 10
	 */
	
	// Vereinfachen Sie und berechnen Sie die Worst-Case-Laufzeit
	public static boolean method5(int[] array) {
		for (int i : array) {
			if (i == 0) {
				return true;
			} else {
				return false;
			}
		}
		return false;
	}
	
	/*
	// Die optimale L�sung
	public static boolean method5_short1(int[] array) {
		return (array.length > 0 && array[0] == 0);
	}
	
	// Reicht auch
	public static boolean method5_short2(int[] array) {
		return array[0] == 0;
	}

	 Laufzeit: Da beim ersten Element bereits auf jeden Fall ein Wert zur�ckgegeben wird,
	  wird die Schleife nicht komplett durchlaufen, es erfolgt immer konstant ein Aufruf. => in O(1)
	 */
	
	// Vereinfachen Sie und geben sie die Worst-Case-Laufzeit, die Anzahl und das Ergebnis der Additionen f�r n=10
	// (Ignorieren sie Inkrementierungen)
	public static int method6(int n) {
		int result = 0;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n - i; i++) {
				if (j == 0) {
					result += i;
				}
			}
		}
		return result;
	}
	
	/*
	// Nur bei j == 0 wird result += i berechnet, somit ist die innere Schleife nutzlos.
	// Also rechnet method6(n) das gleiche wie method1(n), nur unn�tig komplieiert.
	public static int method6_short(int n) {
		int result = 0;
		for (int i = 0; i < n; i++) {
			result += i;
		}
		return result;
	}
	
	Laufzeit Original: Da einmal eine �u�ere Schleife mit n Aufrufen und eine Innere,
	 mit n-i <= n aufrufen verwendet wird, ist das Original in quadratischer Laufzeit => in O(n^2)
	
	Laufzeit Verbessert: Wie method1() => in O(n)
	
	Ergebnis: Wie method1(), also 45
	
	Additionen: Wie method1() => n
	*/
	
	// Geben sie die Worst-Case-Laufzeit (in Abh�ngigkeit data.length) an
	public static boolean method7(boolean[] data) {
		boolean result = true;
		for (int i = 0; i < data.length; i++) {
			for (int j = data.length - 1; j > 0; j /= 2) {
				result &= data[j];
			}
		}
		return result;
	}
	
	/*
	 * Laufzeit: Die �u�ere Schleife wird n Mal aufgerufen => in O(n), die innere wird mit n aufgerufen
	 *  und der Index wird immer weiter halbiert. Das entspricht dem Logarithmus zur Basis zwei => in O(log2(n))
	 *  Zusammen ergibt sich => in O(n * log(n))
	 */
	
	
	// Geben sie die Worst-Case-Laufzeit (in Abh�ngigkeit data.length) an
	public static boolean method8(boolean[] data) {
		if (data.length == 0) {
			return false;
		} else if (data.length < 3) {
			return data[0];
		} else {
			return method8(Arrays.copyOfRange(data, 0, data.length / 3));
		}
	}
	
	/*
	 * Laufzeit: Die Methode wird rekursiv auf ein Teilarray aufgerufen. 
	 * Die L�nge dieses Arrays verringert sich immer wieder um 2/3, somit ist die Laufzeit in O(log3(n)).
	 * Wechselt man die Basis zu log2, wird mit einem konstanten Faktor (1 / log3(2)) multipliziert.
	 * Somit ist O(log3(n)) in O(log2(n)), also gesammt => O(log2(n))
	 */
}

package main;

import java.util.Scanner;

public class Minesweeper {

	/**
	 * @author Luca Dreiling
	 * 
	 *         Feel free to change the three constants below to change the board
	 *         size and number of mines!
	 * 
	 *         P.S.: Do NOT write that many comments but write some if it isn't
	 *         obvious what you're doing. I only did it to help you understand the
	 *         code better:)
	 */

	private static final int WIDTH = 10;
	private static final int HEIGHT = 10;
	private static final int NUM_MINES = 25;

	// Constants stored in an enum type called GameStates, whether the player won,
	// lost or is still playing
	private enum GameStates {
		GAME, WON, LOST
	}

	// Constants stored in an enum type called FieldStates, whether a field is
	// covered, uncovered or is a bomb
	private enum FieldStates {
		COVERED, UNCOVERED, BOMB
	}

	// the state of the game, initialized with the state GAME, since we want to play
	// before winning or loosing
	private static GameStates gameState = GameStates.GAME;

	// the typical numbers shown on a Minesweeper board (calculating the numbers in
	// before h
	private static int[][] dangerBoard = new int[HEIGHT][WIDTH];

	// Board with mines Stores on of the constants in the enum FieldStates
	private static FieldStates[][] mineBoard = new FieldStates[HEIGHT][WIDTH];

	// Storing the number of bomb-free fields here and decreasing it every time we
	// uncover a free field.
	// If it is zero we won:)
	private static int freeFieldsCount;

	// the scanner for console input
	private static Scanner scanner;

	/**
	 * Start of the game. Usually the main function is pretty empty for better
	 * understanding of the program. (e.g. here we only want to start the Game)
	 */

	public static void main(String[] args) {
		scanner = new Scanner(System.in);

		startGame();
	}

	/**
	 * Starting a new game. The game needs to be initialized, then we want to run
	 * the game (looping until we'll win or loose) and finally we print something to
	 * let you know wether or not you won
	 */

	private static void startGame() {
		initializeGame();

		runGameLoop();

		printGameOverMessage();
	}

	/**
	 * Initializing the game. readNextPos returns an int-array of length 2 storing
	 * an x and y value of a field on the board. Since we want to give the player a
	 * chance the first field should never be a bomb. We generate the bombs on the
	 * remaining covered fields and calculate the 'dangerNumbers' afterwards
	 */

	private static void initializeGame() {
		// WIDTH * HEIGHT positions in the field but need to subtract the mines
		freeFieldsCount = WIDTH * HEIGHT - NUM_MINES;
		
		// Printing basic game informations
		System.out.println("Bitte gib den ersten Punkt ein: [Format: x y]");
		System.out.println("Du musst " + freeFieldsCount + " freie Felder finden.");

		// reading the first field
		int[] startPoint = readNextPos();

		// placing the bombs
		initializeBoard(startPoint[0], startPoint[1]);
		// giving the rest of the fields a UNCOVERED state
		initializeFields();
		// uncovering the starting position
		uncoverField(startPoint[0], startPoint[1]);
		// printing the field
		printField();
	}

	/**
	 * Placing the bombs on the board but not on the start position
	 * 
	 * @param x start position x
	 * @param y start position y
	 */

	private static void initializeBoard(int x, int y) {
		// unsing a for loop to place every mine
		for (int i = 0; i < NUM_MINES; i++) {
			// generating a random position
			int posX = (int) (Math.random() * WIDTH);
			int posY = (int) (Math.random() * HEIGHT);

			// generation a new position if the position has already a bomb
			// or is the starting position
			while (mineBoard[posY][posX] == FieldStates.BOMB || (posX == x && posY == y)) {
				posX = (int) (Math.random() * WIDTH);
				posY = (int) (Math.random() * HEIGHT);
			}

			// placing a bomb if a valid position was found
			mineBoard[posY][posX] = FieldStates.BOMB;
		}
	}

	/**
	 * Initializing each field by calculating dangerNumbers and covering it
	 */

	private static void initializeFields() {
		// iterating through the whole field...
		for (int y = 0; y < HEIGHT; y++) {
			for (int x = 0; x < WIDTH; x++) {
				// calculating the number of bombs in a 3x3 square around
				calculateDangerNumber(x, y);
				// if the field has no bomb it should be covered
				if (mineBoard[y][x] != FieldStates.BOMB) {
					mineBoard[y][x] = FieldStates.COVERED;
				}
			}
		}
	}

	/**
	 * running the main game loop. This is basically getting a new field to uncover
	 * and then uncovering it.
	 */

	private static void runGameLoop() {
		// while the game isn't over...
		while (gameState == GameStates.GAME) {
			// first display some game info
			System.out.println("Noch " + freeFieldsCount + " freie Felder. \n" + "Bitte w�hle die naechste Position.");
			// then read the next position to uncover
			int[] pos = readNextPos();
			// uncover the position
			uncoverField(pos[0], pos[1]);
			// finally print the field again for information
			if (gameState == GameStates.GAME) {
				printField();
			}
		}
	}

	/**
	 * We only need to look at the 8 fields surrounding a field to calculate the
	 * dangerNumber for the field. Using a double for-loop we start at x-1 and go to
	 * x+1 and from y-1 to y+1 If a bomb was found we want to increase count and
	 * save it in the dangerBoard
	 * 
	 * @param x position x
	 * @param y position y
	 */

	private static void calculateDangerNumber(int x, int y) {
		int bombCount = 0;
		for (int i = -1; i < 2; i++) {
			for (int j = -1; j < 2; j++) {
				// If the position is on the board and not the field at pos (x,y) and is a
				// bomb...
				if (isInBounds(x + j, y + i) && !(i == 0 && j == 0) && mineBoard[y + i][x + j] == FieldStates.BOMB) {
					// ...increase the danger number by one, since we've found a bomb
					bombCount++;
				}
			}
		}
		// write the number to the dangerBoard
		dangerBoard[y][x] = bombCount;
	}

	/**
	 * Uncovers the field at position (x,y)
	 * 
	 * @param x position x
	 * @param y position y
	 */

	private static void uncoverField(int x, int y) {
		// check and handle if the the game was a bomb or the last covered field
		checkGameOver(mineBoard[y][x]);
		// message if the field is already uncovered
		if (mineBoard[y][x] == FieldStates.UNCOVERED) {
			System.out.println("DU hast das Feld (" + x + " " + y + ") schon aufgedeckt! Du Dulli!");
			System.out.println();
		} else if (mineBoard[y][x] == FieldStates.COVERED) {
			// uncover a covered field
			mineBoard[y][x] = FieldStates.UNCOVERED;

			// uncover all empty connected fields
			if (dangerBoard[y][x] == 0) {
				uncoverSurroundingFields(x, y);
			}
		}
	}

	/**
	 * Uncovers all surrounding fields if they have no bomb in proximity. Checking
	 * the surrounding fields using a similar approach like in
	 * calculateDangerNumbers()
	 * 
	 * @param x position x
	 * @param y position y
	 */

	private static void uncoverSurroundingFields(int x, int y) {
		for (int i = -1; i < 2; i++) {
			for (int j = -1; j < 2; j++) {
				if (isInBounds(x + j, y + i) && mineBoard[y + i][x + j] == FieldStates.COVERED) {
					uncoverField(x + j, y + i);
				}
			}
		}
	}

	/**
	 * Checks if the parameter is a bomb or a free field and changes the gameState
	 * if necessary
	 * 
	 * @param fieldState the fieldState of the uncovered field
	 */

	private static void checkGameOver(FieldStates fieldState) {
		if (fieldState == FieldStates.COVERED) {
			// if we uncovered free field we have one free field less
			freeFieldsCount--;
		} else if (fieldState == FieldStates.BOMB) {
			// if we uncovered a bomb the game is lost
			gameState = GameStates.LOST;
		}
		// if we uncovered all free fields we've won
		if (freeFieldsCount == 0) {
			gameState = GameStates.WON;
		}
	}

	/**
	 * Using a Scanner to read two integers and returning it as an
	 * 2-element-int-array
	 * 
	 * @return an array containing a valid x and y coordinate
	 */

	private static int[] readNextPos() {
		// an 2-element array containing the x and y value
		int[] point = null;

		// repeat asking for inputs until we have a vaild one
		while (point == null) {
			int x = -1;
			int y = -1;
			if (scanner.hasNextInt()) {
				x = scanner.nextInt();
			}
			if (scanner.hasNextInt()) {
				y = scanner.nextInt();
			}

			// check if the entered position is on the field
			if (isInBounds(x, y)) {
				// setting point != null so we'll exit the while-loop
				point = new int[2];
				point[0] = x;
				point[1] = y;
			}
			// kind reminder to enter a valid position
			if (point == null) {
				System.out.println("Denk dran einen Punkt im Spielfeld zu waehlen! \n"
						+ "Denk dran, dass wir bei Null anfangen zu zaehlen, du Dulli.");
			}
		}
		return point;
	}

	/**
	 * Methode for printing the Minesweeper board
	 */

	private static void printField() {
		// printing a chess-like x-scale of numbers
		printXScale();
		for (int y = 0; y < mineBoard.length; y++) {
			// Printing a character y-scale on the left side
			System.out.print(convertNumToChar(y) + " ");
			for (int x = 0; x < mineBoard[0].length; x++) {
				if (mineBoard[y][x] == FieldStates.COVERED || mineBoard[y][x] == FieldStates.BOMB) {
					// Printing an uncovered field
					System.out.print("[X]");
				} else if (mineBoard[y][x] == FieldStates.UNCOVERED && dangerBoard[y][x] == 0) {
					// printing an empty field with no surrounding bombs
					System.out.print("[ ]");
				} else if (mineBoard[y][x] == FieldStates.UNCOVERED) {
					// printing a field with danger number
					System.out.print("[" + dangerBoard[y][x] + "]");
				}
			}
			// y-scale on the right side
			System.out.print(" " + convertNumToChar(y));
			System.out.println();
		}
		// x-scaleagain
		printXScale();
		System.out.println();
	}

	/**
	 * Prints a String of numbers from 0 to WIDTH-1
	 */

	private static void printXScale() {
		System.out.print("  ");
		for (int x = 0; x < WIDTH; x++) {
			System.out.print(" " + x + " ");
		}
		System.out.println();
	}

	/**
	 * Generates an uppercase character from a number. e.g.: convertNumToChar(0) =
	 * 'A', convertNumToChar(1) = 'B', ...
	 * 
	 * @param number the number of the letter in the alphabet
	 * @return an uppercase character
	 */

	private static char convertNumToChar(int number) {
		// using modulo to always get a letter in the alphabet
		return (char) ((number % 26) + 'A');
	}

	/**
	 * Prints the game over message. System.err.println() is for the red font.
	 */

	private static void printGameOverMessage() {
		if (gameState == GameStates.WON) {
			System.err.println("\t Du hast gewonnen!");
		} else if (gameState == GameStates.LOST) {
			System.err.println("\t Verloren...");
		}
	}

	/**
	 * Useful helper function that checks if a position is on the board. Writing
	 * this once helps understanding the code and shortening it.
	 * 
	 * @param x position x
	 * @param y position y
	 * 
	 * @return if (x,y) is on the board
	 */

	private static boolean isInBounds(int x, int y) {
		return (y >= 0 && y < HEIGHT && x >= 0 && x < WIDTH);
	}

}
